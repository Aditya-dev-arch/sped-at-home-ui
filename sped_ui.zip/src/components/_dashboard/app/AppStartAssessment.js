/* eslint-disable */
// material
import { Card, CardHeader, Box } from '@mui/material';

export default function AppStartAssessment() {

    return (
        <Card>
            <CardHeader title="Assessment" subheader="Start assessment for your child" />
            <Box sx={{ p: 3, pb: 1 }} dir="ltr">

            </Box>
        </Card>
    );
}