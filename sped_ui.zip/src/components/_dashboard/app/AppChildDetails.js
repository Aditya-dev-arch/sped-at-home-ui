/* eslint-disable */
// material
import { Card, CardHeader, Box, Avatar, Stack, Typography } from '@mui/material';
import { useState } from 'react';

export default function AppChildDetails() {
  const [avatarUrl, setAvatarUrl] = useState('');
  return (
    <Card>
      <CardHeader title="Child Details" />
      <Stack spacing={2} sx={{ p: 3 }} direction="row" alignItems="center">
        <Avatar src={avatarUrl} sx={{ width: 60, height: 60 }} />
        <Box>
          <Typography variant="subtitle2" noWrap>
            <strong>John Max</strong>
          </Typography>
          <Typography variant="body2" sx={{ color: 'text.secondary' }} noWrap>
            Grade: 5
          </Typography>
        </Box>
      </Stack>
      <Stack spacing={2} sx={{ p: 3 }} direction="row" alignItems="center">
        
          <Typography variant="subtitle2" noWrap>
            Plan Details
          </Typography>
          <Typography variant="caption" sx={{ pr: 3, flexShrink: 0, color: 'text.secondary' }}>
            Hello
          </Typography>
        
      </Stack>

    </Card>
  );
}